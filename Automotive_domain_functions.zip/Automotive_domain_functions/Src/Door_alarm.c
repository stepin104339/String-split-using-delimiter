
#include "stm32f4xx.h"


GPIO_Handle_t Gpioled,Gpioled4,Gpioled2,Gpioled3,Internal_BTN,External_BTN,MotionDctr,GpioledR, GpioledG, GpioledB;


#define 	BTN_PRESSED 	SET
#define 	BTN_PRESSED1 	SET
#define 	HIGH 			SET

void delay(void)
{
	for (uint32_t i=0;i<500000;i++);
}


void Internal_Light(); 				// For internal Light
void Motion_Sensor_Initialization(); 	//Motion detector
void switch_initialization(); 			//To access switches
void Door_Lock_Initialization();		//For Door Lock


int main(void)
{

/*
 * Initialization of all tasks
 */

Door_Lock_Initialization();
switch_initialization();
Internal_Light();

   while(1)
   {
	   if(GPIO_ReadFromInputPin(GPIOA,GPIO_PIN_NO_0)==BTN_PRESSED)
	   {
    		 /*
     		  * if user presses the  internal switch then open all the doors
     		  */
   	            GPIO_WriteToOutputPin(GPIOD, GPIO_PIN_NO_12, 1);
	      	    delay();
	   }
	  else if(GPIO_ReadFromInputPin(GPIOC,GPIO_PIN_NO_0)==(BTN_PRESSED1))
	   {
		/*
		 * if user press external switch then close all the doors and switch on internal light
	 	 */

				 //close all the doors
		       GPIO_WriteToOutputPin(GPIOD, GPIO_PIN_NO_14, 1);
		        delay();

		  	   	//switch on internal led
		       GPIO_ToggleOutputPin(GPIOD,GPIO_PIN_NO_0);
		  	delay();
		       GPIO_ToggleOutputPin(GPIOD,GPIO_PIN_NO_1);
		  	delay();
		       GPIO_ToggleOutputPin(GPIOD,GPIO_PIN_NO_2);
		       delay();
	   }
	   else if((GPIO_ReadFromInputPin(GPIOC,GPIO_PIN_NO_7)==HIGH))
	   {
   		 /*
   		  * if sensor high then toggle 15th led(to indicate motion)
   	          */
                      GPIO_ToggleOutputPin(GPIOD,GPIO_PIN_NO_15);
		       delay();
	   }

	   else
	   {
		   //Reset all the tasks
		   GPIO_WriteToOutputPin(GPIOD, GPIO_PIN_NO_12, 0);
		   GPIO_WriteToOutputPin(GPIOD, GPIO_PIN_NO_14, 0);
		   GPIO_WriteToOutputPin(GPIOD, GPIO_PIN_NO_15, 0);
		   delay();
	   }
   }
	return 0;
}


void Internal_Light()
{
	           /********for rgb******/

	      	   GpioledR.pGPIOx = GPIOD;
	      	   GpioledR.GPIO_PinConfig.GPIO_PinNumber = GPIO_PIN_NO_0;
	      	   GpioledR.GPIO_PinConfig.GPIO_PinMode = GPIO_MODE_OUT;
	      	   GpioledR.GPIO_PinConfig.GPIO_PinSpeed = GPIO_SPEED_MEDIUM;
	      	   GpioledR.GPIO_PinConfig.GPIO_PinPuPdControl = GPIO_NO_PU;
	      	   GpioledR.GPIO_PinConfig.GPIO_PinOPType = GPIO_OP_TYPE_PP;

	      	   GPIO_PeriClockControl(GPIOD,ENABLE);
	      	   GPIO_Init(&GpioledR);

	      	   GpioledG.pGPIOx = GPIOD;
	      	   GpioledG.GPIO_PinConfig.GPIO_PinNumber = GPIO_PIN_NO_1;
	      	   GpioledG.GPIO_PinConfig.GPIO_PinMode = GPIO_MODE_OUT;
	      	   GpioledG.GPIO_PinConfig.GPIO_PinSpeed = GPIO_SPEED_MEDIUM;
	      	   GpioledG.GPIO_PinConfig.GPIO_PinPuPdControl = GPIO_NO_PU;
	      	   GpioledG.GPIO_PinConfig.GPIO_PinOPType = GPIO_OP_TYPE_PP;

	      	   GPIO_PeriClockControl(GPIOD,ENABLE);
	      	   GPIO_Init(&GpioledG);

	      	    GpioledB.pGPIOx = GPIOD;
	      	    GpioledB.GPIO_PinConfig.GPIO_PinNumber = GPIO_PIN_NO_2;
	      	    GpioledB.GPIO_PinConfig.GPIO_PinMode = GPIO_MODE_OUT;
	      	    GpioledB.GPIO_PinConfig.GPIO_PinSpeed = GPIO_SPEED_MEDIUM;
	      	    GpioledB.GPIO_PinConfig.GPIO_PinPuPdControl = GPIO_NO_PU;
	      	    GpioledB.GPIO_PinConfig.GPIO_PinOPType = GPIO_OP_TYPE_PP;

	      	    GPIO_PeriClockControl(GPIOD,ENABLE);
	      	    GPIO_Init(&GpioledB);


}



void switch_initialization()
{
	//for internal switch

	   Internal_BTN.pGPIOx = GPIOA;
	   Internal_BTN.GPIO_PinConfig.GPIO_PinNumber = GPIO_PIN_NO_0;
	   Internal_BTN.GPIO_PinConfig.GPIO_PinMode = GPIO_MODE_IN;
	   Internal_BTN.GPIO_PinConfig.GPIO_PinSpeed = GPIO_SPEED_FAST;
	   Internal_BTN.GPIO_PinConfig.GPIO_PinPuPdControl = GPIO_NO_PD;


	     GPIO_PeriClockControl(GPIOA,ENABLE);
	     GPIO_Init(&Internal_BTN);

	 //for external switch

	     External_BTN.pGPIOx = GPIOC;
	     External_BTN.GPIO_PinConfig.GPIO_PinNumber = GPIO_PIN_NO_0;
	     External_BTN.GPIO_PinConfig.GPIO_PinMode = GPIO_MODE_IN;
	     External_BTN.GPIO_PinConfig.GPIO_PinSpeed = GPIO_SPEED_FAST;
	     External_BTN .GPIO_PinConfig.GPIO_PinPuPdControl = GPIO_NO_PD;

	       GPIO_PeriClockControl(GPIOC,ENABLE);
	       GPIO_Init(&External_BTN);

}

void Door_Lock_Initialization()
{
	//for led

	   Gpioled.pGPIOx = GPIOD;
	   Gpioled.GPIO_PinConfig.GPIO_PinNumber = GPIO_PIN_NO_12;
	   Gpioled.GPIO_PinConfig.GPIO_PinMode = GPIO_MODE_OUT;
	   Gpioled.GPIO_PinConfig.GPIO_PinSpeed = GPIO_SPEED_FAST;
	   Gpioled.GPIO_PinConfig.GPIO_PinPuPdControl = GPIO_NO_PD;
	   Gpioled.GPIO_PinConfig.GPIO_PinOPType = GPIO_OP_TYPE_PP;

	   GPIO_PeriClockControl(GPIOD,ENABLE);
	   GPIO_Init(&Gpioled);

	   Gpioled2.pGPIOx = GPIOD;
	   Gpioled2.GPIO_PinConfig.GPIO_PinNumber = GPIO_PIN_NO_14;
	   Gpioled2.GPIO_PinConfig.GPIO_PinMode = GPIO_MODE_OUT;
	   Gpioled2.GPIO_PinConfig.GPIO_PinSpeed = GPIO_SPEED_FAST;
	   Gpioled2.GPIO_PinConfig.GPIO_PinPuPdControl = GPIO_NO_PD;
	   Gpioled2.GPIO_PinConfig.GPIO_PinOPType = GPIO_OP_TYPE_PP;

	   GPIO_PeriClockControl(GPIOD,ENABLE);
	   GPIO_Init(&Gpioled2);

	   Gpioled3.pGPIOx = GPIOD;
	   Gpioled3.GPIO_PinConfig.GPIO_PinNumber = GPIO_PIN_NO_15;
	   Gpioled3.GPIO_PinConfig.GPIO_PinMode = GPIO_MODE_OUT;
	   Gpioled3.GPIO_PinConfig.GPIO_PinSpeed = GPIO_SPEED_FAST;
	   Gpioled3.GPIO_PinConfig.GPIO_PinPuPdControl = GPIO_NO_PD;
	   Gpioled3.GPIO_PinConfig.GPIO_PinOPType = GPIO_OP_TYPE_PP;

	   GPIO_PeriClockControl(GPIOD,ENABLE);
	   GPIO_Init(&Gpioled3);

}

